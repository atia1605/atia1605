package com.atia.reservation.controller;

import com.atia.reservation.Model.Passenger;
import com.atia.reservation.Service.PassengerService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
@RequestMapping("/passenger")
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // --- Show registration page ---
    @GetMapping("/register")
    public String showRegister(Model model) {
        model.addAttribute("passenger", new Passenger());
        return "register";
    }

    // --- Registration ---
    @PostMapping("/register")
    public String registerPassenger(@Valid @ModelAttribute("passenger") Passenger passenger,
                                    BindingResult result,
                                    Model model) {
        if (result.hasErrors()) return "register";

        if (passengerService.emailExists(passenger.getEmail())) {
            model.addAttribute("error", "Email already registered");
            return "register";
        }

        passenger.setPassword(passwordEncoder.encode(passenger.getPassword()));
        passengerService.registerPassenger(passenger);

        model.addAttribute("success", "Registration successful! Please login.");
        return "redirect:/passenger/login";
    }

    // --- Show login page ---
    @GetMapping("/login")
    public String showLogin() {
        return "login";
    }

    // --- Login ---
    @PostMapping("/login")
    public String loginPassenger(@RequestParam("email") String email,
                                 @RequestParam("password") String password,
                                 Model model,
                                 HttpSession session) {

        Optional<Passenger> passengerOpt = passengerService.findByEmail(email);

        if (passengerOpt.isPresent() &&
            passwordEncoder.matches(password, passengerOpt.get().getPassword())) {

            Passenger passenger = passengerOpt.get();
            // Save in session
            session.setAttribute("loggedInPassenger", passenger);
            return "redirect:/passenger/dashboard";
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }
    }

    // --- Show dashboard ---
    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        Passenger passenger = getLoggedInPassenger();
        if (passenger == null) return "redirect:/passenger/login";

        model.addAttribute("passenger", passenger);
        return "dashboard";
    }

    // --- Show profile ---
    @GetMapping("/profile")
    public String showProfile(@AuthenticationPrincipal org.springframework.security.core.userdetails.UserDetails userDetails,
            Model model) {
if (userDetails == null) {
return "redirect:/passenger/login";
}

// Fetch latest passenger details from DB using email
Optional<Passenger> passengerOpt = passengerService.findByEmail(userDetails.getUsername());
if (passengerOpt.isEmpty()) {
return "redirect:/passenger/login";
}

Passenger passenger = passengerOpt.get();
model.addAttribute("passenger", passenger);

System.out.println("Passenger loaded from DB: " + passenger.getPassengerId());

return "profile"; // renders profile.html
}



    // --- Update profile ---
   
    @PostMapping("/profile/update")
    public String updateProfile(@AuthenticationPrincipal org.springframework.security.core.userdetails.UserDetails userDetails,
                                @RequestParam("firstName") String firstName,
                                @RequestParam("lastName") String lastName,
                                @RequestParam(value = "phone", required = false) String phone,
                                @RequestParam(value = "address", required = false) String address,
                                @RequestParam(value = "city", required = false) String city,
                                @RequestParam(value = "postalCode", required = false) String postalCode,
                                Model model) {

        if (userDetails == null) {
            return "redirect:/passenger/login";
        }

        // Fetch passenger from DB using email
        Optional<Passenger> passengerOpt = passengerService.findByEmail(userDetails.getUsername());
        if (passengerOpt.isEmpty()) {
            return "redirect:/passenger/login";
        }

        Passenger passenger = passengerOpt.get();

        // Update fields
        passenger.setFirstName(firstName);
        passenger.setLastName(lastName);
        passenger.setPhone(phone);
        passenger.setAddress(address);
        passenger.setCity(city);
        passenger.setPostalCode(postalCode);

        // Save updated passenger
        passengerService.updatePassenger(passenger);

        model.addAttribute("passenger", passenger);
        model.addAttribute("successMessage", "Profile updated successfully!");

        return "profile";
    }


    // --- Logout ---
    @GetMapping("/logout")
    public String logout() {
        // Optional: Clear Spring Security context
        SecurityContextHolder.clearContext();
        return "redirect:/passenger/login";
    }

    // --- Helper: get currently logged-in passenger ---
    private Passenger getLoggedInPassenger() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName().equals("anonymousUser")) return null;

        return passengerService.findByEmail(auth.getName()).orElse(null);
    }
}
