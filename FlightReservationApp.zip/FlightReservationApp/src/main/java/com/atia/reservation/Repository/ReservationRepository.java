package com.atia.reservation.Repository;

import com.atia.reservation.Model.Passenger;
import com.atia.reservation.Model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    // Find reservations by passenger email
    List<Reservation> findByEmail(String email);

    // Find reservations by status (Booked, Cancelled, etc.)
    List<Reservation> findByStatus(String status);

    // Find reservations with departure date after a specific date
    List<Reservation> findByDepartureDateAfter(LocalDate date);

    // Find reservations by passenger ID
    List<Reservation> findByPassengerPassengerId(Long passengerId);
   
    List<Reservation> findByPassenger(Passenger passenger);
}
