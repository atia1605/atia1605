package com.atia.reservation.controller;

import com.atia.reservation.Model.Passenger;
import com.atia.reservation.Model.Reservation;
import com.atia.reservation.Service.PassengerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;

@Controller
public class HomeController {

    @Autowired
    private PassengerService passengerService;

    // ---------------- HOME PAGE ----------------
    @GetMapping("/home")
    public String home(Model model, @AuthenticationPrincipal org.springframework.security.core.userdetails.User user) {
        if (user != null) {
            model.addAttribute("username", user.getUsername());
        } else {
            model.addAttribute("username", "Guest");
        }
        return "home"; // home.html
    }

    // ---------------- LOGIN PAGE ----------------
    @GetMapping("/login")
    public String login() {
        return "login"; // login.html
    }

    // ---------------- SIGNUP PAGE ----------------
    @GetMapping("/signup")
    public String signupForm(Model model) {
        model.addAttribute("passenger", new Passenger());
        return "signup"; // signup.html
    }

    // Handle signup submission
    @PostMapping("/signup")
    public String signupSubmit(@Valid @ModelAttribute("passenger") Passenger passenger,
                               BindingResult bindingResult,
                               Model model) {

        if (bindingResult.hasErrors()) {
            return "signup";
        }

        if (passengerService.emailExists(passenger.getEmail())) {
            model.addAttribute("error", "Email already registered");
            return "signup";
        }

        passengerService.registerPassenger(passenger);
        return "redirect:/login?signupSuccess=true";
    }

    // ---------------- BOOK FLIGHT ----------------
    @GetMapping("/book-flight")
    public String bookFlight(Model model, 
                             @AuthenticationPrincipal org.springframework.security.core.userdetails.User user) {

        // Add reservation object
        model.addAttribute("reservation", new Reservation());

        // Add logged-in username
        if (user != null) {
            model.addAttribute("username", user.getUsername());
        } else {
            model.addAttribute("username", "Guest");
        }

        // Add countries and nationalities
        model.addAttribute("countries", getAllCountries());
        model.addAttribute("nationalities", getAllCountries());

        return "book-flight"; // book-flight.html
    }

    // ---------------- HELPER ----------------
    private List<String> getAllCountries() {
        return java.util.Arrays.stream(java.util.Locale.getISOCountries())
                .map(code -> new java.util.Locale("", code).getDisplayCountry())
                .sorted()
                .toList();
    }

    @PostMapping("/book-flight")
    public String handleBookFlight(@ModelAttribute("reservation") Reservation reservation, Model model) {
        // Here you would typically save the reservation using ReservationService (if you have one)
        model.addAttribute("message", "Flight booked successfully!");
        return "redirect:/home";
    }

    // ---------------- MODIFY RESERVATION ----------------
    @GetMapping("/modify-reservation")
    public String modifyReservation(Model model) {
        model.addAttribute("reservation", new Reservation());
        return "modify-reservation"; // modify-reservation.html
    }

    @PostMapping("/modify-reservation")
    public String handleModifyReservation(@ModelAttribute("reservation") Reservation reservation, Model model) {
        // Logic to modify reservation here
        model.addAttribute("message", "Reservation modified successfully!");
        return "redirect:/home";
    }

    // ---------------- CANCEL RESERVATION ----------------
    @GetMapping("/cancel-reservation")
    public String cancelReservation(Model model) {
        model.addAttribute("reservation", new Reservation());
        return "cancel-reservation"; // cancel-reservation.html
    }

    @PostMapping("/cancel-reservation")
    public String handleCancelReservation(@ModelAttribute("reservation") Reservation reservation, Model model) {
        // Logic to cancel reservation here
        model.addAttribute("message", "Reservation cancelled successfully!");
        return "redirect:/home";
    }

    
}
