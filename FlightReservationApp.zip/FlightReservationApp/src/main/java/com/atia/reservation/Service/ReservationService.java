package com.atia.reservation.Service;

import com.atia.reservation.Model.Flight;
import com.atia.reservation.Model.Passenger;
import com.atia.reservation.Model.Reservation;
import com.atia.reservation.Repository.FlightRepository;
import com.atia.reservation.Repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final FlightRepository flightRepository;

    @Autowired
    public ReservationService(ReservationRepository reservationRepository,
                              FlightRepository flightRepository) {
        this.reservationRepository = reservationRepository;
        this.flightRepository = flightRepository;
    }

    /**
     * Create or update a reservation
     */
    public Reservation saveReservation(Reservation reservation) {
        if (reservation == null) {
            throw new IllegalArgumentException("Reservation cannot be null");
        }

        // ✅ Assign a flight automatically based on airline, route, and date
        Flight flight = assignFlightAutomatically(
                reservation.getAirline(),
                reservation.getDepartureCity(),
                reservation.getDestinationCity(),
                reservation.getDepartureDate()
        );
        reservation.setFlight(flight);

        // ✅ Calculate price dynamically
        reservation.calculatePrice();

        // ✅ Set booking date and default status
        reservation.setBookingDate(LocalDate.now());
        if (reservation.getStatus() == null || reservation.getStatus().isEmpty()) {
            reservation.setStatus("Booked");
        }

        // ✅ Save reservation
        return reservationRepository.save(reservation);
    }

    /**
     * Assign an existing flight automatically or create one if not found
     */
    private Flight assignFlightAutomatically(String airline, String departure, String destination, LocalDate date) {
        List<Flight> flights = flightRepository.findByAirlineAndDepartureCityAndDestinationCity(
                airline, departure, destination
        );

        if (flights.isEmpty()) {
            // No existing flight → create a new one
            Flight newFlight = new Flight();
            newFlight.setAirline(airline);
            newFlight.setDepartureCity(departure);
            newFlight.setDestinationCity(destination);
            newFlight.setDepartureTime(date.atStartOfDay());
            newFlight.setArrivalTime(date.atStartOfDay().plusHours(3)); // Default 3 hours flight

            // Default base price by airline
            double basePrice = switch (airline) {
                case "Air Canada" -> 1200;
                case "Delta Airlines" -> 1100;
                case "Emirates" -> 1500;
                case "Lufthansa" -> 1300;
                case "Qatar Airways" -> 1600;
                default -> 1000;
            };

            newFlight.setPrice(basePrice);
            return flightRepository.save(newFlight);
        }

        // If flights exist, randomly assign one
        return flights.get(new Random().nextInt(flights.size()));
    }

    /**
     * Find reservation by ID
     */
    public Optional<Reservation> getReservationById(Long id) {
        if (id == null) return Optional.empty();
        return reservationRepository.findById(id);
    }

    /**
     * Find reservations by Passenger ID
     */
    public List<Reservation> getReservationsByPassenger(Long passengerId) {
        if (passengerId == null) {
            throw new IllegalArgumentException("Passenger ID cannot be null");
        }
        return reservationRepository.findByPassengerPassengerId(passengerId);
    }

    public List<Reservation> getReservationsByPassenger(Passenger passenger) {
        return reservationRepository.findByPassenger(passenger);
    }

    /**
     * Cancel (delete) a reservation by ID
     */
    public boolean cancelReservation(Long id) {
        if (id == null || !reservationRepository.existsById(id)) {
            return false;
        }
        reservationRepository.deleteById(id);
        return true;
    }

    /**
     * Get all reservations (for admin or reporting)
     */
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }
}
