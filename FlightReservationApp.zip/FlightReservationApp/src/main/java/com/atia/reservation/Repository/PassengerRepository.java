package com.atia.reservation.Repository;





import com.atia.reservation.Model.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger, Long> {

    // Find passenger by email (for login/authentication)
    Optional<Passenger> findByEmail(String email);

    // Optional: Check if email already exists during registration
    boolean existsByEmail(String email);
}


