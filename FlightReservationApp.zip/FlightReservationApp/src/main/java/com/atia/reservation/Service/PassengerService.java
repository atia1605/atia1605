package com.atia.reservation.Service;

import com.atia.reservation.Model.Passenger;
import org.springframework.transaction.annotation.Transactional;
import com.atia.reservation.Repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PassengerService implements UserDetailsService {

    @Autowired
    private PassengerRepository passengerRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // -------------------- Spring Security authentication --------------------
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Passenger passenger = passengerRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("No user found with email: " + email));

        return User.builder()
                .username(passenger.getEmail())
                .password(passenger.getPassword())
                .authorities(Collections.singleton(() -> "ROLE_USER")) // assign ROLE_USER
                .build();
    }

    // -------------------- Passenger operations --------------------
    public Optional<Passenger> findByEmail(String email) {
        if (email == null || email.isBlank()) return Optional.empty();
        return passengerRepository.findByEmail(email);
    }

    public boolean emailExists(String email) {
        if (email == null || email.isBlank()) return false;
        return passengerRepository.existsByEmail(email);
    }

    public Passenger registerPassenger(Passenger passenger) {
        if (passenger == null || passenger.getPassword() == null) {
            throw new IllegalArgumentException("Passenger or password cannot be null");
        }
        // Encrypt password before saving
        passenger.setPassword(passwordEncoder.encode(passenger.getPassword()));
        return passengerRepository.save(passenger);
    }

    public Optional<Passenger> getPassengerById(Long id) {
        if (id == null) return Optional.empty();
        return passengerRepository.findById(id);
    }
   
    public Passenger updatePassenger(Passenger passenger) {
        if (passenger == null || passenger.getPassengerId() == null) {
            throw new IllegalArgumentException("Passenger or ID cannot be null");
        }
        return passengerRepository.save(passenger);
    }

    // -------------------- New method to fetch all passengers --------------------
    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }
}
