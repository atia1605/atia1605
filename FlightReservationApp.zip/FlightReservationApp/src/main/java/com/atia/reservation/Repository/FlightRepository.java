package com.atia.reservation.Repository;

import com.atia.reservation.Model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {

    // Find flights by departure and destination cities
    List<Flight> findByDepartureCityAndDestinationCity(String departureCity, String destinationCity);

    // Find flights by airline
    List<Flight> findByAirline(String airline);  
    
    //Find flights by departure city only.
    List<Flight> findByDepartureCity(String departureCity);

    List<Flight> findByAirlineAndDepartureCityAndDestinationCity(String airline, String departure , String  destination);
     // Find flights by destination city only.
     
    List<Flight> findByDestinationCity(String destinationCity);

    // Optional: Find flights departing after a certain date
    List<Flight> findByDepartureTimeAfter(LocalDateTime dateTime);
    
    List<Flight> findByDepartureCityAndDestinationCityAndDepartureTimeAfter(
            String departureCity, String destinationCity, LocalDateTime departureTime);
}
