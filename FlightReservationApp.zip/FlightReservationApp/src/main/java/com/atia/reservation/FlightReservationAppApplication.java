
/*/
 * Name: Atia Nahia
 *Student ID: 301314834
 *Date:02/10/2025
/*/




package com.atia.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightReservationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightReservationAppApplication.class, args);
	}

}
