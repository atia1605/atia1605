package com.atia.reservation.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "flight")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "flight_id")
    private Long flightId;  // matches BIGINT in MySQL

    @NotBlank(message = "Airline name is required")
    @Column(name = "airline_name", nullable = false)
    private String airline;

    @NotNull(message = "Departure time is required")
    @Column(name = "departure_time", nullable = false)
    private LocalDateTime departureTime;

    @NotNull(message = "Arrival time is required")
    @Column(name = "arrival_time", nullable = false)
    private LocalDateTime arrivalTime;

    @NotBlank(message = "Origin city is required")
    @Column(name = "origin", nullable = false)
    private String departureCity;

    @NotBlank(message = "Destination city is required")
    @Column(name = "destination", nullable = false)
    private String destinationCity;

    @Positive(message = "Price must be positive")
    @Column(nullable = false)
    private double price;

    @OneToMany(mappedBy = "flight", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Reservation> reservations;

    // -------------------- Utility Methods --------------------
    /**
     * Dynamically generate flight number using flightId
     */
    @Transient
    public String getFlightNumber() {
        if (flightId != null) {
            return "FL" + flightId;
        }
        return null;
    }

    // -------------------- Validation --------------------
    @PrePersist
    @PreUpdate
    private void validateTimes() {
        if (departureTime != null && arrivalTime != null && !departureTime.isBefore(arrivalTime)) {
            throw new IllegalArgumentException("Departure time must be before arrival time");
        }
    }

    // -------------------- Getters & Setters --------------------
    public Long getFlightId() { return flightId; }
    public void setFlightId(Long flightId) { this.flightId = flightId; }

    public String getAirline() { return airline; }
    public void setAirline(String airline) { this.airline = airline; }

    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }

    public LocalDateTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalDateTime arrivalTime) { this.arrivalTime = arrivalTime; }

    public String getDepartureCity() { return departureCity; }
    public void setDepartureCity(String departureCity) { this.departureCity = departureCity; }

    public String getDestinationCity() { return destinationCity; }
    public void setDestinationCity(String destinationCity) { this.destinationCity = destinationCity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public List<Reservation> getReservations() { return reservations; }
    public void setReservations(List<Reservation> reservations) { this.reservations = reservations; }

    @Override
    public String toString() {
        return "Flight{" +
                "flightId=" + flightId +
                ", airline='" + airline + '\'' +
                ", departureTime=" + departureTime +
                ", arrivalTime=" + arrivalTime +
                ", departureCity='" + departureCity + '\'' +
                ", destinationCity='" + destinationCity + '\'' +
                ", price=" + price +
                '}';
    }
}
