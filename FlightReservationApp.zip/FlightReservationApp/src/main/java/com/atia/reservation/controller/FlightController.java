package com.atia.reservation.controller;



import com.atia.reservation.Model.Flight;
import com.atia.reservation.Service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class FlightController {

    @Autowired
    private FlightService flightService;

    // List all available flights
    @GetMapping("/flights")
    public String listFlights(Model model) {
        List<Flight> flights = flightService.getAllFlights();
        model.addAttribute("flights", flights);
        return "flights";  // flights.html
    }

    // Show booking form for selected flight
    @GetMapping("/flights/book/{id}")
    public String bookFlightForm(@PathVariable("id") Long flightId, Model model) {
        Flight flight = flightService.getFlightById(flightId).orElse(null);
        if (flight == null) {
            return "redirect:/flights";
        }
        model.addAttribute("flight", flight);
        return "book-flight"; // book-flight.html
    }
}
