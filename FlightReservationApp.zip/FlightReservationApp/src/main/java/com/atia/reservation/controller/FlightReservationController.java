package com.atia.reservation.controller;

import com.atia.reservation.Model.Reservation;
import com.atia.reservation.Model.Flight;
import com.atia.reservation.Model.Passenger;
import com.atia.reservation.Service.ReservationService;
import com.atia.reservation.Service.FlightService;
import com.atia.reservation.Service.PassengerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

@Controller
@RequestMapping("/reservation")
public class FlightReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private PassengerService passengerService;

    @Autowired
    private FlightService flightService;

    // -------------------- SHOW BOOK FLIGHT FORM --------------------
    @GetMapping("/book-flight")
    public String showBookingForm(Model model) {
        Passenger passenger = getLoggedInPassenger();
        if (passenger == null) {
            return "redirect:/passenger/login";
        }

        Reservation reservation = new Reservation();
        reservation.setPassenger(passenger);

        model.addAttribute("reservation", reservation);

        // Populate flight select options
        populateFormModel(model);

        List<String> allCountries = getAllCountries();
        model.addAttribute("countries", allCountries);
        model.addAttribute("nationalities", allCountries);

        return "book-flight";
    }

    // Helper method
    private Passenger getLoggedInPassenger() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName().equals("anonymousUser")) return null;

        return passengerService.findByEmail(auth.getName()).orElse(null);
    }

    // -------------------- BOOK NEW RESERVATION --------------------
    @PostMapping("/book-flight")
    public String bookReservation(@Valid @ModelAttribute Reservation reservation,
                                  BindingResult result,
                                  Model model) {

        if (result.hasErrors()) {
            populateFormModel(model);
            model.addAttribute("countries", getAllCountries());
            model.addAttribute("nationalities", getAllCountries());
            return "book-flight";
        }

        // -------------------- 1️⃣ Assign Flight Automatically --------------------
        Flight assignedFlight = flightService.assignFlightAutomatically(
                reservation.getAirline(),
                reservation.getDepartureCity(),
                reservation.getDestinationCity(),
                reservation.getDepartureDate()
        );

        if (assignedFlight == null) {
            // Create new flight only with essential info — price will be set by reservation
            assignedFlight = new Flight();
            assignedFlight.setAirline(reservation.getAirline());
            assignedFlight.setDepartureCity(reservation.getDepartureCity());
            assignedFlight.setDestinationCity(reservation.getDestinationCity());

            // Default departure + arrival
            assignedFlight.setDepartureTime(reservation.getDepartureDate().atTime(9, 0));
            assignedFlight.setArrivalTime(reservation.getDepartureDate().atTime(12, 0));

            // Minimal info to satisfy validation
            assignedFlight.setPrice(1.0);

            // Save flight first to generate flightId
            assignedFlight = flightService.saveFlight(assignedFlight);
        }

        // -------------------- 2️⃣ Reservation Details --------------------
        reservation.setFlight(assignedFlight);
        reservation.setBookingDate(LocalDate.now());
        reservation.setStatus("Booked");

        // -------------------- 3️⃣ Auto Calculate Price After Form Fill --------------------
        reservation.calculatePrice();

        // -------------------- 4️⃣ Save Reservation --------------------
        reservationService.saveReservation(reservation);

        // -------------------- 5️⃣ Return Confirmation Page --------------------
        model.addAttribute("reservation", reservation);
        model.addAttribute("successMessage", "Reservation booked successfully! Flight Number: " + assignedFlight.getFlightNumber());
        return "modify-reservation"; // <-- renders confirmation.html
    }

    // -------------------- HELPER --------------------
    private List<String> getAllCountries() {
        return Arrays.stream(java.util.Locale.getISOCountries())
                .map(code -> new java.util.Locale("", code).getDisplayCountry())
                .sorted()
                .collect(Collectors.toList());
    }

    private void populateFormModel(Model model) {
        model.addAttribute("flights", flightService.getAllFlights());
    }
}
