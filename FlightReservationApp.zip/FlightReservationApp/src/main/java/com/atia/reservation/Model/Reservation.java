/*
 * Name: Atia Nahia
 * Student ID: 301314834
 * Date: 02/10/2025
 */

package com.atia.reservation.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Email;
import java.time.LocalDate;
import java.util.Optional;

@Entity
@Table(name = "reservation")
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reservation_id")
    private Long reservationId;

    // -------------------- Relationships --------------------
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "passenger_id", referencedColumnName = "passenger_id", nullable = false)
    private Passenger passenger;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id", referencedColumnName = "flight_id")
    private Flight flight;

    @Column(name = "booking_date")
    private LocalDate bookingDate;

    // -------------------- Personal Info --------------------
    private String prefix;

    @NotBlank(message = "First name is required")
    @Column(name = "first_name")
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @NotBlank(message = "Last name is required")
    @Column(name = "last_name")
    private String lastName;

    private String address;

    @Column(name = "address_line2")
    private String addressLine2;

    private String city;
    private String province;
    private String zip;
    @NotBlank(message = "Country is required")
    private String country;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    private String phone;

    @Column(name = "passport_number")
    private String passportNumber;

    @NotBlank(message = "Nationality is required")
    private String nationality;

    @Column(name = "passport_issue_date")
    private LocalDate passportIssueDate;

    @Column(name = "passport_expiry_date")
    private LocalDate passportExpiryDate;

    // -------------------- Flight Info --------------------
    @NotBlank(message = "Trip type is required")
    @Column(name = "trip_type")
    private String tripType;

    @NotBlank(message = "Departure city is required")
    @Column(name = "departure_city")
    private String departureCity;

    @NotBlank(message = "Destination city is required")
    @Column(name = "destination_city")
    private String destinationCity;

    private String airline;

    @Future(message = "Departure date must be in the future")
    @Column(name = "departure_date")
    private LocalDate departureDate;

    @Column(name = "return_date", nullable = true)
    private LocalDate returnDate; // Can be null for one-way trips

    @Min(value = 1, message = "At least 1 adult required")
    private int adults = 1;

    private double price;

    private String status; // Booked, Cancelled, etc.

    // -------------------- Utility Methods --------------------
    public String getFullName() {
        StringBuilder sb = new StringBuilder();
        if (prefix != null && !prefix.isEmpty()) sb.append(prefix).append(" ");
        if (firstName != null && !firstName.isEmpty()) sb.append(firstName).append(" ");
        if (middleName != null && !middleName.isEmpty()) sb.append(middleName).append(" ");
        if (lastName != null && !lastName.isEmpty()) sb.append(lastName);
        return sb.toString().trim();
    }

    public String getFullAddress() {
        StringBuilder sb = new StringBuilder();
        if (address != null && !address.isEmpty()) sb.append(address).append(", ");
        if (addressLine2 != null && !addressLine2.isEmpty()) sb.append(addressLine2).append(", ");
        if (city != null && !city.isEmpty()) sb.append(city).append(", ");
        if (province != null && !province.isEmpty()) sb.append(province).append(", ");
        if (zip != null && !zip.isEmpty()) sb.append(zip).append(", ");
        if (country != null && !country.isEmpty()) sb.append(country);
        return sb.toString().replaceAll(", $", "");
    }

    public void calculatePrice() {
        if (adults <= 0) adults = 1;
        if (tripType == null) tripType = "One-Way";

        double basePrice = (flight != null && flight.getPrice() > 0) ? flight.getPrice() : switch (airline) {
            case "Air Canada" -> 1200;
            case "Delta Airlines" -> 1100;
            case "Emirates" -> 1500;
            case "Lufthansa" -> 1300;
            case "Qatar Airways" -> 1600;
            default -> 1000;
        };

        if ("Round-Trip".equalsIgnoreCase(tripType)) basePrice *= 1.5;

        this.price = basePrice * adults;
    }

    @PrePersist
    protected void onCreate() {
        bookingDate = LocalDate.now();
    }

    // -------------------- Getters & Setters --------------------
    public Long getReservationId() { return reservationId; }
    public void setReservationId(Long reservationId) { this.reservationId = reservationId; }
    
    public Passenger getPassenger() { return passenger; }
    public void setPassenger(Passenger passenger) { this.passenger = passenger; }

    
    public Flight getFlight() { return flight; }
    public void setFlight(Flight flight) { this.flight = flight; }
   
    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }
    
    public String getPrefix() { return prefix; }
    public void setPrefix(String prefix) { this.prefix = prefix; }
    
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getMiddleName() { return middleName; }
    
    public void setMiddleName(String middleName) { this.middleName = middleName; }
    public String getLastName() { return lastName; }
    
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getAddressLine2() { return addressLine2; }
    public void setAddressLine2(String addressLine2) { this.addressLine2 = addressLine2; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getProvince() { return province; }
    public void setProvince(String province) { this.province = province; }
    public String getZip() { return zip; }
    public void setZip(String zip) { this.zip = zip; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getPassportNumber() { return passportNumber; }
    public void setPassportNumber(String passportNumber) { this.passportNumber = passportNumber; }
    public String getNationality() { return nationality; }
    public void setNationality(String nationality) { this.nationality = nationality; }
    public LocalDate getPassportIssueDate() { return passportIssueDate; }
    public void setPassportIssueDate(LocalDate passportIssueDate) { this.passportIssueDate = passportIssueDate; }
    public LocalDate getPassportExpiryDate() { return passportExpiryDate; }
    public void setPassportExpiryDate(LocalDate passportExpiryDate) { this.passportExpiryDate = passportExpiryDate; }
    public String getTripType() { return tripType; }
    public void setTripType(String tripType) { this.tripType = tripType; }
    public String getDepartureCity() { return departureCity; }
    public void setDepartureCity(String departureCity) { this.departureCity = departureCity; }
    public String getDestinationCity() { return destinationCity; }
    public void setDestinationCity(String destinationCity) { this.destinationCity = destinationCity; }
    public String getAirline() { return airline; }
    public void setAirline(String airline) { this.airline = airline; }
    public LocalDate getDepartureDate() { return departureDate; }
    public void setDepartureDate(LocalDate departureDate) { this.departureDate = departureDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public int getAdults() { return adults; }
    public void setAdults(int adults) { this.adults = adults; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
