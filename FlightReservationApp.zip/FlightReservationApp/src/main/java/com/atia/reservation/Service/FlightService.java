package com.atia.reservation.Service;

import com.atia.reservation.Model.Flight;
import com.atia.reservation.Repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class FlightService {

    @Autowired
    private FlightRepository flightRepository;

    // Get all flights
    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    // Get flight by ID
    public Optional<Flight> getFlightById(Long flightId) {
        return flightRepository.findById(flightId);
    }

    // Find flights by origin and destination
    public List<Flight> findFlights(String origin, String destination) {
        return flightRepository.findByDepartureCityAndDestinationCity(origin, destination);
    }

    // Find flights by airline
    public List<Flight> findFlightsByAirline(String airline) {
        return flightRepository.findByAirline(airline);
    }
    
    public List<Flight> searchFlights(String origin, String destination, LocalDateTime afterTime) {
        if (afterTime != null) {
            return flightRepository.findByDepartureCityAndDestinationCityAndDepartureTimeAfter(origin, destination, afterTime);
        }
        return flightRepository.findByDepartureCityAndDestinationCity(origin, destination);
    }



    // Find flights departing after a certain date/time
    public List<Flight> findFlightsAfterDate(LocalDateTime departureTime) {
        return flightRepository.findByDepartureTimeAfter(departureTime);
    }

    // Add or update flight
    public Flight saveFlight(Flight flight) {
        return flightRepository.save(flight);
    }
    public Flight assignFlightAutomatically(String airline, String departure, String destination, LocalDate date) {
        List<Flight> flights = flightRepository.findByAirlineAndDepartureCityAndDestinationCity(airline, departure, destination);

        if (flights.isEmpty()) {
            // Create a new flight automatically if none exist
            Flight newFlight = new Flight();
            newFlight.setAirline(airline);
            newFlight.setDepartureCity(departure);
            newFlight.setDestinationCity(destination);
            newFlight.setDepartureTime(date.atStartOfDay()); // or set a default time
            return flightRepository.save(newFlight);
        }

        // Pick a random flight from available flights
        return flights.get(new Random().nextInt(flights.size()));
    }



    // Delete flight
    public void deleteFlight(Long flightId) {
        flightRepository.deleteById(flightId);
    }
}
