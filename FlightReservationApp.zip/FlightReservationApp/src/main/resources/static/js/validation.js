/*/
 * Name: Atia Nahia
 * Student ID: 301314834
 * Date: 02/10/2025
/*/

// -----------------------------
// FORM VALIDATION
// -----------------------------
function validateForm() {
    const email = document.getElementById("email").value.trim();
    const departure = document.getElementById("departureCity").value;
    const arrival = document.getElementById("destinationCity").value;
    const today = new Date().toISOString().split('T')[0];

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    // Departure / Destination check
    if (departure === arrival) {
        alert("Departure and destination cannot be the same.");
        return false;
    }

    const depDate = document.getElementById("departureDate").value;
    const retDate = document.getElementById("returnDate").value;

    if (!depDate || depDate < today) {
        alert("Departure date must be in the future.");
        return false;
    }

    if (retDate && retDate < depDate) {
        alert("Return date must be after departure date.");
        return false;
    }

    return true;
}

// -----------------------------
// PRICE CALCULATION
// -----------------------------
function calculatePrice() {
    const airline = document.getElementById("airline").value;
    const tripTypeRadio = document.querySelector("input[name='tripType']:checked");
    const tripType = tripTypeRadio ? tripTypeRadio.value : "One-Way";
    const adults = parseInt(document.getElementById("adults").value) || 1;
    const children = parseInt(document.getElementById("children").value) || 0;

    let basePrice = 1000;

    switch (airline) {
        case "Air Canada": basePrice = 1200; break;
        case "Delta Airlines": basePrice = 1100; break;
        case "Emirates": basePrice = 1500; break;
        case "Lufthansa": basePrice = 1300; break;
        case "Qatar Airways": basePrice = 1600; break;
    }

    if (tripType === "Round-Trip") basePrice *= 1.5;

    // Assuming children pay 50% of adult price
    const totalPrice = (adults + 0.5 * children) * basePrice;
    document.getElementById("price").value = totalPrice.toFixed(2);
}

// -----------------------------
// CANCEL RESERVATION CHECK
// -----------------------------
function canCancelReservation(departureDateStr) {
    const departureDate = new Date(departureDateStr);
    const today = new Date();
    const diffTime = departureDate - today;
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    return diffDays >= 10;
}

// -----------------------------
// ATTACH EVENTS AFTER LOAD
// -----------------------------
document.addEventListener("DOMContentLoaded", function() {
    const airlineDropdown = document.getElementById("airline");
    const tripRadios = document.querySelectorAll("input[name='tripType']");
    const adultsInput = document.getElementById("adults");
    const childrenInput = document.getElementById("children");
    const form = document.querySelector("form");

    // Calculate price initially
    calculatePrice();

    if (airlineDropdown) airlineDropdown.addEventListener("change", calculatePrice);
    if (tripRadios) tripRadios.forEach(r => r.addEventListener("change", calculatePrice));
    if (adultsInput) adultsInput.addEventListener("input", calculatePrice);
    if (childrenInput) childrenInput.addEventListener("input", calculatePrice);

    if (form) form.onsubmit = validateForm;
});
